import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User as AuthUser, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { User, Post, Bit } from '@/types/user';

interface UserContextType {
  currentUser: User | null;
  session: Session | null;
  posts: Post[];
  bits: Bit[];
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password: string, username: string, displayName: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  createPost: (content: string, image?: string) => void;
  createBit: (bitData: Omit<Bit, 'id' | 'author' | 'createdAt' | 'views' | 'likes' | 'isLiked'>) => void;
  updateProfile: (userData: Partial<User>) => void;
  loading: boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [bits, setBits] = useState<Bit[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        
        if (session?.user) {
          // Fetch user profile from profiles table
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();
            
          if (profile) {
            const user: User = {
              id: profile.id,
              username: profile.username,
              email: session.user.email || '',
              displayName: profile.name,
              avatar: profile.avatar_url,
              bio: profile.bio,
              joinedDate: new Date(profile.created_at).toISOString().split('T')[0],
              followers: 0,
              following: 0,
              verified: false
            };
            setCurrentUser(user);
          }
        } else {
          setCurrentUser(null);
        }
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: 'An unexpected error occurred' };
    }
  };

  const register = async (email: string, password: string, username: string, displayName: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const redirectUrl = `${window.location.origin}/`;
      
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            username,
            name: displayName,
          }
        }
      });

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: 'An unexpected error occurred' };
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
  };

  const createPost = (content: string, image?: string) => {
    if (!currentUser) return;

    const newPost: Post = {
      id: crypto.randomUUID(),
      author: currentUser,
      content,
      image,
      createdAt: new Date().toISOString(),
      likes: 0,
      reposts: 0,
      comments: 0,
      isLiked: false,
      isReposted: false
    };

    setPosts(prev => [newPost, ...prev]);
  };

  const createBit = (bitData: Omit<Bit, 'id' | 'author' | 'createdAt' | 'views' | 'likes' | 'isLiked'>) => {
    if (!currentUser) return;

    const newBit: Bit = {
      ...bitData,
      id: crypto.randomUUID(),
      author: currentUser,
      createdAt: new Date().toISOString(),
      views: 0,
      likes: 0,
      isLiked: false
    };

    setBits(prev => [newBit, ...prev]);
  };

  const updateProfile = async (userData: Partial<User>) => {
    if (!currentUser || !session) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          name: userData.displayName,
          bio: userData.bio,
          avatar_url: userData.avatar,
        })
        .eq('id', currentUser.id);

      if (!error) {
        const updatedUser = { ...currentUser, ...userData };
        setCurrentUser(updatedUser);
      }
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  return (
    <UserContext.Provider value={{
      currentUser,
      session,
      posts,
      bits,
      login,
      register,
      logout,
      createPost,
      createBit,
      updateProfile,
      loading
    }}>
      {children}
    </UserContext.Provider>
  );
};
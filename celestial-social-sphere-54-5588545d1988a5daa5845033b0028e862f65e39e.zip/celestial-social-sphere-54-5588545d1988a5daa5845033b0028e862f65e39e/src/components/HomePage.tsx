import { useState, useEffect } from 'react';
import { 
  Star, 
  Search, 
  Menu, 
  X, 
  Home, 
  User, 
  Bell, 
  MessageCircle, 
  Heart, 
  Repeat, 
  Share, 
  Image as ImageIcon, 
  Video, 
  Smile, 
  Play,
  Users,
  Settings,
  LogOut,
  Verified,
  Plus,
  Upload,
  Bookmark,
  Compass,
  Mail
} from 'lucide-react';
import StarField from './StarField';
import VideoModal from './VideoModal';
import { PostCard } from '@/components/PostCard';
import { BitCard } from '@/components/BitCard';
import { SearchModal } from '@/components/SearchModal';
import { NotificationCenter } from '@/components/NotificationCenter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { useUser } from '@/contexts/UserContext';
import { useSocialStore } from '@/stores/socialStore';

interface HomePageProps {
  onLogout?: () => void;
  onNavigate?: (page: string) => void;
  onOpenUpload?: (type: 'post' | 'bit') => void;
}

const HomePage = ({ onLogout, onNavigate, onOpenUpload }: HomePageProps) => {
  const { currentUser, createPost } = useUser();
  const { posts, bits, initializeMockData } = useSocialStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [postText, setPostText] = useState('');
  const [selectedBit, setSelectedBit] = useState<any>(null);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);

  useEffect(() => {
    initializeMockData();
  }, [initializeMockData]);
  
  const handleCreatePost = () => {
    if (postText.trim()) {
      createPost(postText);
      setPostText('');
    }
  };

  const handleBitClick = (bit: any) => {
    setSelectedBit(bit);
    setIsVideoModalOpen(true);
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) {
        setSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="min-h-screen relative">
      <StarField />
      
      {/* Header */}
      <header className="sticky top-0 z-50 glass-effect border-b border-border">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Star className="w-8 h-8 text-accent" fill="currentColor" />
            <span className="text-xl font-bold text-accent">Celestial</span>
          </div>
          
          <div className="flex-1 max-w-xl mx-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search Celestial..."
                className="pl-10 bg-input/50 border-border focus:border-accent cursor-pointer"
                onClick={() => setIsSearchOpen(true)}
                readOnly
              />
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(true)}
            className="relative hover:bg-accent/10"
          >
            <Menu className="w-6 h-6 text-accent" />
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-destructive rounded-full flex items-center justify-center text-xs font-bold text-white">
              3
            </div>
          </Button>
        </div>
      </header>

      {/* Sidebar */}
      <div className={`fixed inset-y-0 right-0 z-50 w-80 glass-effect border-l border-border transform transition-transform ${
        sidebarOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-accent">Menu</h3>
            <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)}>
              <X className="w-5 h-5 text-accent" />
            </Button>
          </div>
          
          {/* User Profile */}
          <div className="flex items-center gap-3 p-4 rounded-xl bg-accent/10 mb-6">
            <Avatar className="w-12 h-12 ring-2 ring-accent/20">
              <AvatarImage src={currentUser?.avatar} alt={currentUser?.displayName} />
              <AvatarFallback>
                {currentUser?.displayName.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold">{currentUser?.displayName}</h3>
              <p className="text-sm text-muted-foreground">@{currentUser?.username}</p>
            </div>
          </div>
          
          {/* Menu Items */}
          <div className="space-y-6">
            <div className="menu-section">
              <h4 className="text-sm font-semibold text-accent mb-3 px-3">Navigation</h4>
              <div className="menu-items space-y-1">
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => setActiveTab('home')}>
                  <Home className="w-5 h-5" />
                  <span>Home</span>
                </div>
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => onNavigate?.('profile')}>
                  <User className="w-5 h-5" />
                  <span>Profile</span>
                </div>
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => setIsNotificationOpen(true)}>
                  <Bell className="w-5 h-5" />
                  <span>Notifications</span>
                  <div className="ml-auto w-5 h-5 bg-destructive rounded-full flex items-center justify-center text-xs font-bold text-white">
                    3
                  </div>
                </div>
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => onNavigate?.('messages')}>
                  <Mail className="w-5 h-5" />
                  <span>Messages</span>
                </div>
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => onNavigate?.('bookmarks')}>
                  <Bookmark className="w-5 h-5" />
                  <span>Bookmarks</span>
                </div>
              </div>
            </div>

            <div className="menu-section">
              <h4 className="text-sm font-semibold text-accent mb-3 px-3">Create</h4>
              <div className="menu-items space-y-1">
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => onOpenUpload?.('post')}>
                  <Plus className="w-5 h-5" />
                  <span>New Post</span>
                </div>
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => onOpenUpload?.('bit')}>
                  <Upload className="w-5 h-5" />
                  <span>Upload Bit</span>
                </div>
              </div>
            </div>

            <div className="menu-section">
              <h4 className="text-sm font-semibold text-accent mb-3 px-3">Discover</h4>
              <div className="menu-items space-y-1">
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => onNavigate?.('explore')}>
                  <Compass className="w-5 h-5" />
                  <span>Explore</span>
                </div>
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer">
                  <Star className="w-5 h-5" />
                  <span>Trending</span>
                </div>
              </div>
            </div>

            <div className="menu-section">
              <h4 className="text-sm font-semibold text-accent mb-3 px-3">Settings</h4>
              <div className="menu-items space-y-1">
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-accent/10 hover:text-accent transition-colors cursor-pointer" onClick={() => onNavigate?.('settings')}>
                  <Settings className="w-5 h-5" />
                  <span>Settings</span>
                </div>
                <div className="menu-item flex items-center gap-3 p-3 rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors cursor-pointer" onClick={onLogout}>
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 py-6 relative z-10">
        {/* Tab Navigation */}
        <div className="flex mb-6 glass-effect rounded-xl p-1">
          {[
            { id: 'home', label: 'Home' },
            { id: 'trending', label: 'Trending' },
            { id: 'bits', label: '30s Bits' },
            { id: 'following', label: 'Following' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-cosmic text-white shadow-glow-primary'
                  : 'text-muted-foreground hover:text-accent'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Post Creation */}
        <Card className="glass-effect border-border mb-6 hover-lift">
          <CardContent className="p-6">
            <div className="flex gap-4 mb-4">
              <Avatar className="w-10 h-10">
                <AvatarImage src={currentUser?.avatar} alt={currentUser?.displayName} />
                <AvatarFallback>
                  {currentUser?.displayName.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <Textarea
                placeholder="What's happening in your universe?"
                value={postText}
                onChange={(e) => setPostText(e.target.value)}
                className="flex-1 bg-transparent border-border focus:border-accent resize-none"
                rows={3}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex gap-4">
                <Button variant="ghost" size="icon" className="text-accent hover:bg-accent/10" onClick={() => onOpenUpload?.('post')}>
                  <ImageIcon className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-accent hover:bg-accent/10" onClick={() => onOpenUpload?.('bit')}>
                  <Video className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-accent hover:bg-accent/10">
                  <Smile className="w-5 h-5" />
                </Button>
              </div>
              <Button 
                variant="cosmic" 
                onClick={handleCreatePost}
                className="ml-auto"
                disabled={!postText.trim()}
              >
                Post
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* 30 Second Bits Section */}
        {activeTab === 'home' && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Video className="w-5 h-5 text-accent" />
                30-Second Bits
              </h3>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => onOpenUpload?.('bit')}
              >
                <Plus className="w-4 h-4 mr-2" />
                Upload
              </Button>
            </div>
            <div className="flex gap-4 overflow-x-auto pb-4">
              {bits.length === 0 ? (
                <Card className="min-w-[200px] bg-card/80 backdrop-blur-md border-border/50">
                  <CardContent className="p-6 text-center">
                    <Video className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">No bits yet</p>
                    <p className="text-xs text-muted-foreground mt-1">Be the first to share!</p>
                  </CardContent>
                </Card>
              ) : (
                bits.map((bit) => (
                  <Card key={bit.id} className="min-w-[200px] bg-card/80 backdrop-blur-md border-border/50 hover:scale-105 transition-transform cursor-pointer" onClick={() => handleBitClick(bit)}>
                    <div className="relative">
                      <img
                        src={bit.thumbnail}
                        alt={bit.title}
                        className="w-full h-32 object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 bg-black/20 rounded-t-lg flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Play className="w-8 h-8 text-white" />
                      </div>
                    </div>
                    <CardContent className="p-3">
                      <h4 className="font-medium text-sm mb-1">{bit.title}</h4>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Avatar className="w-5 h-5">
                          <AvatarImage src={bit.author.avatar} alt={bit.author.name} />
                          <AvatarFallback>{bit.author.name[0]}</AvatarFallback>
                        </Avatar>
                        <span>{bit.author.name}</span>
                        <span>•</span>
                        <span>{bit.views} views</span>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        )}

        {/* Posts Feed */}
        <div className="space-y-6">
          {posts.length === 0 ? (
            <Card className="bg-card/80 backdrop-blur-md border-border/50">
              <CardContent className="p-8 text-center">
                <MessageCircle className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">Welcome to Celestial!</h3>
                <p className="text-muted-foreground mb-4">Share your first cosmic thought with the universe.</p>
                <Button variant="cosmic" onClick={() => onOpenUpload?.('post')}>
                  Create Your First Post
                </Button>
              </CardContent>
            </Card>
          ) : (
            posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))
          )}
        </div>

        {/* Bits Feed for Bits Tab */}
        {activeTab === 'bits' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {bits.map((bit) => (
              <BitCard 
                key={bit.id} 
                bit={bit} 
                onPlay={() => {
                  setSelectedBit(bit);
                  setIsVideoModalOpen(true);
                }}
              />
            ))}
          </div>
        )}

        {/* Modals */}
        <SearchModal 
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
        />
        
        <NotificationCenter 
          isOpen={isNotificationOpen}
          onClose={() => setIsNotificationOpen(false)}
        />

        <VideoModal
          isOpen={isVideoModalOpen}
          onClose={() => setIsVideoModalOpen(false)}
          bit={selectedBit}
        />
      </main>
    </div>
  );
};

export default HomePage;
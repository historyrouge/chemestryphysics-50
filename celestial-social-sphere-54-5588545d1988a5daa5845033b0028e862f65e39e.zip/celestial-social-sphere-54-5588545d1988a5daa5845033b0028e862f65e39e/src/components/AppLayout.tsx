import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import HomePage from './HomePage';
import ProfilePage from './ProfilePage';
import NotificationsPage from './NotificationsPage';
import MessagesPage from './MessagesPage';
import ExplorePage from './ExplorePage';
import BookmarksPage from './BookmarksPage';
import SettingsPage from './SettingsPage';
import UploadModal from './UploadModal';

type PageType = 'home' | 'profile' | 'explore' | 'notifications' | 'messages' | 'bookmarks' | 'settings';

const AppLayout = () => {
  const { logout } = useUser();
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [uploadType, setUploadType] = useState<'post' | 'bit'>('post');

  const handleOpenUpload = (type: 'post' | 'bit') => {
    setUploadType(type);
    setUploadModalOpen(true);
  };

  const handleNavigation = (page: string) => {
    setCurrentPage(page as PageType);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'profile':
        return <ProfilePage onNavigateBack={() => setCurrentPage('home')} />;
      case 'notifications':
        return <NotificationsPage onNavigateBack={() => setCurrentPage('home')} />;
      case 'messages':
        return <MessagesPage onNavigateBack={() => setCurrentPage('home')} />;
      case 'explore':
        return <ExplorePage onNavigateBack={() => setCurrentPage('home')} />;
      case 'bookmarks':
        return <BookmarksPage onNavigateBack={() => setCurrentPage('home')} />;
      case 'settings':
        return <SettingsPage onNavigateBack={() => setCurrentPage('home')} onLogout={logout} />;
      case 'home':
      default:
        return (
          <HomePage 
            onLogout={logout}
            onNavigate={handleNavigation}
            onOpenUpload={handleOpenUpload}
          />
        );
    }
  };

  return (
    <>
      {renderCurrentPage()}
      <UploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        type={uploadType}
      />
    </>
  );
};

export default AppLayout;
import { useState } from 'react';
import { Heart, MessageCircle, Share, Bookmark, MoreHorizontal } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useSocialStore, type Post } from '@/stores/socialStore';
import { useToast } from '@/hooks/use-toast';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const { toggleLikePost, toggleBookmarkPost, addComment, sharePost, toggleLikeComment } = useSocialStore();
  const { toast } = useToast();

  const handleLike = () => {
    toggleLikePost(post.id);
    toast({
      description: post.isLiked ? "Removed from favorites" : "Added to favorites ✨",
    });
  };

  const handleBookmark = () => {
    toggleBookmarkPost(post.id);
    toast({
      description: post.isBookmarked ? "Removed from bookmarks" : "Bookmarked for later 🔖",
    });
  };

  const handleShare = () => {
    sharePost(post.id);
    navigator.clipboard.writeText(`Check out this cosmic post: ${post.content}`);
    toast({
      description: "Link copied to clipboard! 🌟",
    });
  };

  const handleAddComment = () => {
    if (newComment.trim()) {
      addComment(post.id, newComment);
      setNewComment('');
      toast({
        description: "Comment added! 💫",
      });
    }
  };

  const timeAgo = (timestamp: string) => {
    const now = new Date();
    const posted = new Date(timestamp);
    const diffInHours = Math.floor((now.getTime() - posted.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  return (
    <Card className="cosmic-card group">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="ring-2 ring-cosmic-accent/20">
              <AvatarImage src={post.author.avatar} alt={post.author.name} />
              <AvatarFallback className="bg-cosmic-gradient text-cosmic-text">
                {post.author.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-cosmic-text">{post.author.name}</p>
              <p className="text-sm text-cosmic-muted">@{post.author.username} • {timeAgo(post.timestamp)}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-cosmic-text leading-relaxed">{post.content}</p>
        
        {post.imageUrl && (
          <div className="rounded-lg overflow-hidden">
            <img 
              src={post.imageUrl} 
              alt="Post content" 
              className="w-full h-auto object-cover hover:scale-105 transition-transform duration-300"
            />
          </div>
        )}
        
        <div className="flex items-center justify-between pt-3 border-t border-cosmic-border">
          <div className="flex items-center gap-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              className={`gap-2 hover:text-cosmic-accent transition-colors ${
                post.isLiked ? 'text-cosmic-accent' : 'text-cosmic-muted'
              }`}
            >
              <Heart className={`h-4 w-4 ${post.isLiked ? 'fill-current' : ''}`} />
              <span>{post.likes}</span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="gap-2 text-cosmic-muted hover:text-cosmic-accent transition-colors"
            >
              <MessageCircle className="h-4 w-4" />
              <span>{post.comments.length}</span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleShare}
              className="gap-2 text-cosmic-muted hover:text-cosmic-accent transition-colors"
            >
              <Share className="h-4 w-4" />
              <span>{post.shares}</span>
            </Button>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBookmark}
            className={`hover:text-cosmic-accent transition-colors ${
              post.isBookmarked ? 'text-cosmic-accent' : 'text-cosmic-muted'
            }`}
          >
            <Bookmark className={`h-4 w-4 ${post.isBookmarked ? 'fill-current' : ''}`} />
          </Button>
        </div>
        
        {showComments && (
          <div className="space-y-4 pt-4 border-t border-cosmic-border">
            {post.comments.map((comment) => (
              <div key={comment.id} className="flex gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={comment.author.avatar} alt={comment.author.name} />
                  <AvatarFallback className="bg-cosmic-gradient text-cosmic-text text-xs">
                    {comment.author.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                  <div className="bg-cosmic-secondary/50 rounded-lg p-3">
                    <p className="font-medium text-sm text-cosmic-text">{comment.author.name}</p>
                    <p className="text-cosmic-text">{comment.content}</p>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-cosmic-muted">
                    <span>{timeAgo(comment.timestamp)}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleLikeComment(post.id, comment.id)}
                      className={`gap-1 h-auto p-0 ${
                        comment.isLiked ? 'text-cosmic-accent' : 'text-cosmic-muted'
                      }`}
                    >
                      <Heart className={`h-3 w-3 ${comment.isLiked ? 'fill-current' : ''}`} />
                      <span>{comment.likes}</span>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            
            <div className="flex gap-3 pt-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-cosmic-gradient text-cosmic-text text-xs">
                  You
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-2">
                <Textarea
                  placeholder="Add a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="min-h-[60px] resize-none bg-cosmic-secondary/30 border-cosmic-border"
                />
                <Button 
                  onClick={handleAddComment}
                  disabled={!newComment.trim()}
                  size="sm"
                  className="cosmic-button"
                >
                  Comment
                </Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}